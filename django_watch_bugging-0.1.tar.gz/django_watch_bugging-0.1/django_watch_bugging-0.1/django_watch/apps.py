from django.apps import AppConfig


class DjangoWatchBuggingConfig(AppConfig):
    name = 'django_watch'
